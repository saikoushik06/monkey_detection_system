import tensorflow as tf
import keras

print(tf.__version__)
print(keras.__version__)