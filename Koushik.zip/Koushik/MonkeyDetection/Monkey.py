import cv2
import numpy as np
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
import base64
from flask import Flask, render_template, request, jsonify
import pygame
import io

# Initialize Flask app
app = Flask(__name__)

# Initialize Pygame mixer
pygame.mixer.init()

# Load the buzzer sound
pygame.mixer.music.load('sounds/buzzer.mp3')

# Load the pre-trained MobileNetV2 model
model = MobileNetV2(weights='imagenet')

# List of keywords related to monkeys
monkey_keywords = [
    "monkey", "chimpanzee", "gibbon", "macaque", "baboon", "mandrill", 
    "langur", "colobus", "tamarin", "howler", "spider monkey", "saki", 
    "capuchin", "guenon", "vervet", "proboscis", "marmoset", "lemur", 
    "gorilla", "orangutan"
]

# Function to detect monkey in the image
def detect_monkey_from_base64(image_data_url):
    # Decode base64 image and convert to OpenCV format
    _, encoded = image_data_url.split(',', 1)
    image_data = base64.b64decode(encoded)
    nparr = np.frombuffer(image_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # Resize image to 224x224
    img_resized = cv2.resize(img, (224, 224))
    img_array = np.expand_dims(img_resized, axis=0)
    img_array = preprocess_input(img_array)
    
    # Make predictions
    predictions = model.predict(img_array)
    decoded_predictions = decode_predictions(predictions, top=3)[0]

    # Check if any of the top 3 predictions are related to monkeys
    detected = False
    for _, label, _ in decoded_predictions:
        for keyword in monkey_keywords:
            if keyword.lower() in label.lower():
                detected = True
                break
        if detected:
            break
    
    return detected

# Route to serve index.html
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle image detection
@app.route('/detect', methods=['POST'])
def detect():
    # Get base64 image data from POST request
    image_data_url = request.json['image']

    # Call detect_monkey_from_base64 to detect monkey
    monkey_detected = detect_monkey_from_base64(image_data_url)

    # Play buzzer sound if monkey detected
    if monkey_detected:
        pygame.mixer.music.play()

    # Return JSON response
    return jsonify({'detected': monkey_detected})

if __name__ == '__main__':
    app.run(debug=True)
